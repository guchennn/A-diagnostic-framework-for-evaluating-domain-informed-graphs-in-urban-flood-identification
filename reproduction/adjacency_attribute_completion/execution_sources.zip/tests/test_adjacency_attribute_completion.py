"""Protocol-critical completion-run checks, without GPU training."""

import importlib.util
import json
from pathlib import Path

import pandas as pd
import pytest

SPEC = importlib.util.spec_from_file_location(
    "adjacency_runner",
    Path(__file__).resolve().parents[1] / "scripts/run_adjacency_attribute_completion.py",
)
runner = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(runner)


def test_missing_matrix_excludes_main_and_has_exact_replication():
    config = runner.configuration()
    assert runner.plan(config) == {
        "run_id": "adjacency-attributes-v1-20261124",
        "blocks": 130,
        "selections": 260,
        "inner_candidate_tasks": 520,
        "inner_fits": 1560,
        "outer_fits": 780,
    }
    for city in config["cities"]:
        blocks = runner.blocks(config, city)
        assert len(blocks) == 65
        assert (
            len({(b["outer_fold"], b["budget"], b["trajectory"], b["feature_set"]) for b in blocks})
            == 65
        )
        assert not any(b["feature_set"] == "F18" and b["budget"] == "100" for b in blocks)
        assert all((b["trajectory"] == "NA") == (b["budget"] == "FULL") for b in blocks)
    assert [v["id"] for v in config["variants"]] == ["FF-G1-1", "SAGE-G1-2"]


def test_new_namespace_changes_storage_identity_only():
    config = runner.configuration()
    unit = runner.E1OuterUnit("beijing", 0, "FULL", "NA")
    for variant in config["variants"]:
        for seed in ["HPO-1", "NEURAL-1"]:
            old = runner.historical.make_task(
                {"protocol_id": "P"}, unit, variant, "SMALL", seed, "F18"
            )
            new = runner.historical.make_task(
                {"protocol_id": "P"}, unit, variant, "SMALL", seed, "F18", config["run_id"]
            )
            old_fields, new_fields = old.as_dict(), new.as_dict()
            assert new_fields.pop("experiment_id") == config["run_id"] + (
                "-inner" if seed == "HPO-1" else ""
            )
            old_fields.pop("experiment_id")
            assert new_fields == old_fields
            assert new.feature_set == "FULL-COMMON"
            assert new.graph_id == "G1"


def test_independent_selection_and_outer_epochs(monkeypatch, tmp_path):
    config = runner.configuration()
    monkeypatch.setattr(runner, "ROOT", tmp_path)
    block = runner.blocks(config, "zhengzhou")[0]
    raw = pd.DataFrame({"second": [2.0], "first": [1.0], "excluded": [3.0]})
    fold = {"raw": raw}
    monkeypatch.setattr(runner.e1, "_inner_fold_data", lambda *a: fold)
    monkeypatch.setattr(runner.e1, "_outer_fold_data", lambda *a: fold)
    candidates, refits, selections = [], [], []

    def inner(root, destination, task, data, grid, *, prepared_folds):
        assert len(prepared_folds) == 3
        assert list(prepared_folds[0]["raw"].columns) == ["second", "first"]
        candidates.append(task)
        return "success"

    def select(root, destination, unit, *, task_keys, models, alternative_order):
        assert len(task_keys) == 2
        assert {t.config for t in task_keys} == {"SMALL", "MEDIUM"}
        assert {t.model for t in task_keys} == set(models)
        assert {t.graph_id for t in task_keys} == {"G1"}
        assert alternative_order == models
        selections.append(models[0])
        if models[0] == "Fixed-filter":
            choice = {"config": "MEDIUM", "best_epochs": [4, 8, 6]}
        else:
            choice = {"config": "SMALL", "best_epochs": [9, 3, 6]}
        return {"models": {models[0]: choice}}

    def outer(destination, task, fold, grid, *, epochs):
        refits.append((task, epochs))
        assert list(fold["raw"].columns) == ["second", "first"]
        return "success"

    monkeypatch.setattr(runner.e1, "run_inner_task", inner)
    monkeypatch.setattr(runner.e1, "select_outer_models", select)
    monkeypatch.setattr(runner.e1, "run_outer_fit", outer)
    runner.selected_block(
        config, {"data": {}, "grid": {"protocol_id": "P"}}, block, ["first", "second"]
    )
    assert len(candidates) == 4 and len(refits) == 6
    assert selections == ["Fixed-filter", "GraphSAGE-G2"]
    for task, epochs in refits:
        assert epochs == 6
        assert task.config == ("MEDIUM" if task.model == "Fixed-filter" else "SMALL")
    assert {t.seed for t, _ in refits} == {"NEURAL-1", "NEURAL-2", "NEURAL-3"}
    saved = list((runner.run_path(config) / "selections").glob("*.json"))
    assert len(saved) == 1
    assert set(json.loads(saved[0].read_text())["variants"]) == {"FF-G1-1", "SAGE-G1-2"}


def test_resume_verifies_payload_and_freeze_never_overwrites(tmp_path):
    payload = tmp_path / "inner_scores.parquet"
    payload.write_bytes(b"original")
    status = tmp_path / "status.json"
    value = {"status": "success", "result_sha256": runner.sha256_file(payload)}
    runner.immutable_json(status, value)
    runner.immutable_json(status, value)
    assert runner.succeeded(status, payload.name, "result_sha256")
    payload.write_bytes(b"changed")
    with pytest.raises(ValueError, match="payload changed"):
        runner.succeeded(status, payload.name, "result_sha256")
    with pytest.raises(ValueError, match="refusing"):
        runner.immutable_json(status, {"status": "failed"})
    assert json.loads(status.read_text()) == value


@pytest.mark.parametrize(
    "field,value",
    [
        ("status", "failed"),
        ("epochs", 2),
        ("epochs", True),
        ("cell", {}),
        ("performance_blind", False),
        ("predictions_written", True),
        ("metrics_computed", True),
        ("completion_lock_sha256", "wrong"),
        ("lock_sha256", "wrong"),
        ("source_sha256", "wrong"),
        ("input_sha256", "wrong"),
    ],
)
def test_probe_rejects_invalid_gate_fields(field, value):
    lock = {"source_sha256": "source", "input_sha256": "input"}
    receipt = {
        "status": "success",
        "epochs": 1,
        "cell": runner.revision.PROBE_CELL,
        "performance_blind": True,
        "predictions_written": False,
        "metrics_computed": False,
        "completion_lock_sha256": "completion",
        "lock_sha256": "revision",
        **lock,
    }
    runner.validate_probe(receipt, "completion", "revision", lock)
    receipt[field] = value
    with pytest.raises(ValueError, match=field):
        runner.validate_probe(receipt, "completion", "revision", lock)


def test_added_config_gets_new_probe_binding_without_touching_history(monkeypatch, tmp_path):
    config = runner.configuration()
    monkeypatch.setattr(runner, "ROOT", tmp_path)
    artifacts = tmp_path / "artifacts"
    artifacts.mkdir()
    (artifacts / "protocol_lock.json").write_text("protocol")
    (artifacts / "environment_lock.json").write_text(
        json.dumps(
            {
                "environment": {},
                "protocol_lock_sha256": runner.sha256_file(artifacts / "protocol_lock.json"),
            }
        )
    )
    previous = artifacts / "existing"
    previous.mkdir()
    existing = previous / "local_environment_lock.json"
    existing.write_text("original bytes")
    monkeypatch.setattr(runner, "validate_environment_probe", lambda *a: None)
    monkeypatch.setattr(runner, "identity", lambda *a: {})
    monkeypatch.setattr(runner.revision, "prepare_plan", lambda *a: {"source_sha256": "source"})
    new_files = {"data/frozen": "oldhash", runner.CONFIG: "newconfig"}
    monkeypatch.setattr(runner.revision, "_input_identity", lambda *a: dict(new_files))
    monkeypatch.setattr(runner.revision, "_environment", lambda: {"gpu": "test"})
    monkeypatch.setattr(
        runner.revision,
        "_require_local_lock",
        lambda *a: pytest.fail("old allowlist excludes the new config"),
    )
    monkeypatch.setattr(
        runner.revision,
        "freeze_local_environment",
        lambda *a: pytest.fail("must not rewrite existing lock"),
    )
    runner.freeze(config)
    assert existing.read_text() == "original bytes"
    fresh = runner.require_probe_environment(config)
    assert fresh["files"] == new_files
    assert fresh["input_sha256"] == runner.sha256_bytes(runner.canonical_json_bytes(new_files))
    binding = json.loads((runner.run_path(config) / "local_environment_lock.json").read_text())
    assert binding["revision_lock"].endswith("probe_environment_lock.json")
    assert binding["revision_lock_sha256"] == runner.sha256_file(
        tmp_path / binding["revision_lock"]
    )
    new_files[runner.CONFIG] = "changed-after-freeze"
    with pytest.raises(ValueError, match="probe environment changed"):
        runner.require_probe_environment(config)


def test_probe_resume_never_calls_historical_probe(monkeypatch, tmp_path):
    config = runner.configuration()
    monkeypatch.setattr(runner, "ROOT", tmp_path)
    path = runner.run_path(config) / "resource_probe.json"
    path.parent.mkdir(parents=True)
    path.write_text('{"status": "success"}')
    calls = []
    monkeypatch.setattr(runner, "require_lock", lambda c, **kw: calls.append(kw))
    monkeypatch.setattr(
        runner.revision,
        "run_local_probe",
        lambda *a: pytest.fail("must not call historical probe writer"),
    )
    assert runner.probe(config) == {"status": "success"}
    assert calls == [{"probe": False}, {}]
