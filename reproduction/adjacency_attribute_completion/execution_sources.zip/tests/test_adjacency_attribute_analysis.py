"""Protocol and evidence-integrity checks for the Table 6 completion analysis."""

import importlib.util
import json
from itertools import product
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

SCRIPT = Path(__file__).resolve().parents[1] / "scripts/analyze_adjacency_attribute_completion.py"
SPEC = importlib.util.spec_from_file_location("adjacency_analysis", SCRIPT)
analysis = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(analysis)


def bank_frame(scores=(0.8, 0.8, 0.1)):
    return pd.DataFrame(
        [
            {
                "seed": "NEURAL-1",
                "bank_id": bank,
                "grid_id": str(index),
                "sample_role": "positive" if index == 0 else "background",
                "score": score,
            }
            for bank, (index, score) in product(("1", "2", "3"), enumerate(scores))
        ]
    )


def full_units():
    rows = []
    for condition in analysis.conditions():
        draws = analysis.historical.TRAJECTORIES if condition[3] == "100" else ("NA",)
        for fold, draw, seed in product(range(5), draws, analysis.historical.SEEDS):
            rows.append(
                dict(zip(analysis.KEYS, condition, strict=True))
                | {
                    "outer_fold": fold,
                    "trajectory": draw,
                    "seed": seed,
                    "own": 0.2,
                    "adjacency": 0.3,
                    "d8": 0.3 + fold / 100,
                    "d8_minus_own": 0.1 + fold / 100,
                    "d8_minus_adjacency": fold / 100,
                }
            )
    return pd.DataFrame(rows)


def test_tied_scores_use_threshold_precision_and_pair_by_bank_membership():
    frame = bank_frame()
    score, _ = analysis.bank_metrics(frame, "NEURAL-1")
    assert score == 0.5
    different = frame.copy()
    different.loc[0, "grid_id"] = "changed"
    with pytest.raises(ValueError, match="banks differ"):
        analysis.pair_metrics({"own": frame, "d8": frame, "adjacency": different}, "NEURAL-1")


def test_missing_bank_and_duplicate_cell_rejected():
    frame = bank_frame()
    with pytest.raises(ValueError, match="three evaluation banks"):
        analysis.bank_metrics(frame.loc[frame.bank_id.ne("3")], "NEURAL-1")
    with pytest.raises(ValueError, match="duplicate bank cells"):
        analysis.bank_metrics(pd.concat([frame, frame.iloc[:1]]), "NEURAL-1")


def test_per_fit_ap_precedes_averaging():
    first, _ = analysis.bank_metrics(bank_frame((0.9, 0.8, 0.1)), "NEURAL-1")
    second, _ = analysis.bank_metrics(bank_frame((0.1, 0.8, 0.9)), "NEURAL-1")
    assert np.mean([first, second]) == pytest.approx(2 / 3)
    ensemble, _ = analysis.bank_metrics(bank_frame((0.5, 0.8, 0.5)), "NEURAL-1")
    assert ensemble != pytest.approx(np.mean([first, second]))


def test_complete_matrix_equal_fold_and_paired_resampling():
    units = full_units()
    folds, summary = analysis.summarize_units(units)
    assert len(units) == 1080
    assert len(folds) == 120
    assert len(summary) == 120
    selected = summary.loc[summary.quantity.eq("d8_minus_adjacency")]
    assert np.allclose(selected["mean"], 0.02)
    draws = np.random.default_rng(20261011).integers(0, 5, (10000, 5))
    expected = np.quantile((np.arange(5) / 100)[draws].mean(axis=1), [0.025, 0.975])
    assert np.allclose(selected.range_low, expected[0])
    assert np.allclose(selected.range_high, expected[1])
    assert len(analysis.table_rows(summary)) == 24


def test_missing_unit_and_duplicate_unit_rejected_before_summary():
    units = full_units()
    with pytest.raises(ValueError, match="matrix is incomplete"):
        analysis.summarize_units(units.iloc[1:])
    with pytest.raises(ValueError, match="duplicate paired units"):
        analysis.summarize_units(pd.concat([units, units.iloc[:1]]))


def test_payload_hash_and_task_identity_checked(tmp_path):
    key = analysis.historical.task(
        "beijing",
        0,
        "1",
        "FF-G1-1",
        "SMALL",
        "NEURAL-1",
        analysis.RUN_NAME,
    )
    folder = tmp_path / "outer/tasks" / key.relative_path()
    folder.mkdir(parents=True)
    payload = folder / "oof.parquet"
    payload.write_bytes(b"fixture payload")
    status = folder / "status.json"
    record = {
        "status": "success",
        "task": key.as_dict(),
        "oof_sha256": analysis.sha256_file(payload),
    }
    status.write_text(json.dumps(record), encoding="utf-8")
    assert analysis.checked_payload(tmp_path, key, "outer", {}) == payload
    payload.write_bytes(b"tampered")
    with pytest.raises(ValueError, match="hash mismatch"):
        analysis.checked_payload(tmp_path, key, "outer", {})
    record["status"] = "failed"
    status.write_text(json.dumps(record), encoding="utf-8")
    with pytest.raises(ValueError, match="incomplete or mismatched"):
        analysis.checked_payload(tmp_path, key, "outer", {})
