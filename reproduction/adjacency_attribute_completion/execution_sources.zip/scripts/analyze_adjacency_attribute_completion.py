"""Complete Table 6 using matched archived fits; no fitting or outer selection."""

from __future__ import annotations

import argparse
import json
import sys
from itertools import product
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

import analyze_minor_revision as historical

from floodgnn_ceus.io import sha256_file

RUN_NAME = "adjacency-attributes-v1-20261124"
KEYS = ["city", "predictor", "feature_set", "budget"]
SUMMARY_FIELDS = [
    "mean",
    "range_low",
    "range_high",
    "t_low",
    "t_high",
    "positive_folds",
    "negative_folds",
    "fold0",
    "fold1",
    "fold2",
    "fold3",
    "fold4",
]


def conditions():
    return product(historical.CITIES, ("FF", "SAGE"), historical.FEATURE_LABELS, ("100", "FULL"))


def variants(predictor: str) -> dict[str, str]:
    depth = 1 if predictor == "FF" else 2
    return {
        name: f"{predictor}-G{graph}-{depth}"
        for name, graph in (("own", 0), ("adjacency", 1), ("d8", 2))
    }


def checked_payload(root: Path, key, stage: str, receipts: dict) -> Path:
    status = root / stage / "tasks" / key.relative_path() / "status.json"
    record = json.loads(status.read_text("utf-8"))
    if record.get("status") != "success" or record.get("task") != key.as_dict():
        raise ValueError(f"incomplete or mismatched fit: {status}")
    filename, field = (
        ("oof.parquet", "oof_sha256")
        if stage == "outer"
        else ("inner_scores.parquet", "result_sha256")
    )
    payload = status.with_name(filename)
    digest = sha256_file(payload)
    if digest != record.get(field):
        raise ValueError(f"payload hash mismatch: {payload}")
    receipts[str(status)] = sha256_file(status)
    receipts[str(payload)] = digest
    return payload


def bank_metrics(frame: pd.DataFrame, seed: str) -> tuple[float, pd.DataFrame]:
    frame = frame.loc[frame.seed.eq(seed) & frame.bank_id.isin(("1", "2", "3"))].copy()
    if set(frame.bank_id) != {"1", "2", "3"}:
        raise ValueError("three evaluation banks are required")
    if frame.duplicated(["bank_id", "grid_id"]).any() or not np.isfinite(frame.score).all():
        raise ValueError("duplicate bank cells or non-finite scores")
    values = []
    for bank in ("1", "2", "3"):
        part = frame.loc[frame.bank_id.eq(bank)].sort_values("grid_id")
        labels = part.sample_role.eq("positive").to_numpy(np.int8)
        if not labels.any() or labels.all():
            raise ValueError("bank must contain positives and background")
        values.append(historical.positive_terms(labels, part.score.to_numpy(float))[:, 0].sum())
    signature = (
        frame[["bank_id", "grid_id", "sample_role"]]
        .sort_values(["bank_id", "grid_id"])
        .reset_index(drop=True)
    )
    return float(np.mean(values)), signature


def pair_metrics(frames: dict[str, pd.DataFrame], seed: str) -> dict[str, float]:
    computed = {name: bank_metrics(frame, seed) for name, frame in frames.items()}
    reference = computed["d8"][1]
    if any(not value[1].equals(reference) for value in computed.values()):
        raise ValueError("paired evaluation banks differ")
    result = {name: value[0] for name, value in computed.items()}
    result["d8_minus_own"] = result["d8"] - result["own"]
    result["d8_minus_adjacency"] = result["d8"] - result["adjacency"]
    return result


def inventory(root: Path) -> tuple[list[dict], dict]:
    """Require the entire matrix before computing or publishing aggregate results."""
    new = root / "artifacts/remote_runs" / RUN_NAME
    main = root / "artifacts/remote_runs/reviewer-revision-v1-0d119f16fcb9"
    old = root / "artifacts/remote_runs/minor-revision-controls-v1"
    receipts, units = {}, []
    selection_paths, inner_paths, new_outer_paths = set(), set(), set()
    for city, predictor, feature, budget in conditions():
        base = feature == "F18" and budget == "100"
        draws = historical.TRAJECTORIES if budget == "100" else ("NA",)
        for fold, draw in product(range(5), draws):
            suffix = f"attributes-{city}-f{fold}-b{budget}-t{draw}-{feature}.json"
            old_selection = (
                main / "selections" / f"{city}-f{fold}-b100-t{draw}.json"
                if base
                else old / "selections" / suffix
            )
            new_selection = old_selection if base else new / "selections" / suffix
            selections = {}
            for path in (old_selection, new_selection):
                selections[path] = json.loads(path.read_text("utf-8"))["variants"]
                receipts[str(path)] = sha256_file(path)
            if not base:
                selection_paths.add(new_selection)
            for seed in historical.SEEDS:
                paths = {}
                for role, variant in variants(predictor).items():
                    run = main if base else new if role == "adjacency" else old
                    selection = new_selection if role == "adjacency" else old_selection
                    chosen = selections[selection][variant]
                    experiment = "reviewer-revision-v1" if base else run.name
                    key = historical.task(
                        city,
                        fold,
                        draw,
                        variant,
                        chosen["config"],
                        seed,
                        experiment,
                        historical.FEATURE_LABELS[feature],
                        budget,
                    )
                    paths[role] = checked_payload(run, key, "outer", receipts)
                    if run == new:
                        new_outer_paths.add(paths[role])
                        if seed == "NEURAL-1":
                            for candidate in ("SMALL", "MEDIUM"):
                                inner = historical.task(
                                    city,
                                    fold,
                                    draw,
                                    variant,
                                    candidate,
                                    "HPO-1",
                                    f"{RUN_NAME}-inner",
                                    historical.FEATURE_LABELS[feature],
                                    budget,
                                )
                                inner_paths.add(checked_payload(new, inner, "inner", receipts))
                units.append(
                    dict(zip(KEYS, (city, predictor, feature, budget), strict=True))
                    | {
                        "outer_fold": fold,
                        "trajectory": draw,
                        "seed": seed,
                        "paths": paths,
                    }
                )
    if (len(selection_paths), len(inner_paths), len(new_outer_paths)) != (130, 520, 780):
        raise ValueError("new experiment inventory differs from the specified matrix")
    return units, receipts


def summarize_units(units: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    metrics = ["own", "adjacency", "d8", "d8_minus_own", "d8_minus_adjacency"]
    if units.duplicated([*KEYS, "outer_fold", "trajectory", "seed"]).any():
        raise ValueError("duplicate paired units")
    expected = {
        (*condition, fold, draw, seed)
        for condition in conditions()
        for fold, draw, seed in product(
            range(5),
            historical.TRAJECTORIES if condition[3] == "100" else ("NA",),
            historical.SEEDS,
        )
    }
    actual = set(
        units[[*KEYS, "outer_fold", "trajectory", "seed"]].itertuples(
            index=False,
            name=None,
        )
    )
    if actual != expected:
        raise ValueError("paired unit matrix is incomplete or contains unexpected units")
    folds = units.groupby([*KEYS, "outer_fold"], sort=True)[metrics].mean().reset_index()
    draws = np.random.default_rng(20261011).integers(0, 5, (10000, 5))
    summaries = []
    for key, group in folds.groupby(KEYS, sort=True):
        if set(group.outer_fold) != set(range(5)):
            raise ValueError("five complete outer folds are required")
        group = group.sort_values("outer_fold")
        identity = dict(zip(KEYS, key, strict=True))
        for metric in metrics:
            summaries.append(
                identity
                | {"quantity": metric}
                | historical.describe(
                    group[metric].to_numpy(),
                    draws,
                )
            )
    return folds, pd.DataFrame(summaries)


def preserve_existing(root: Path, summary: pd.DataFrame) -> float:
    """Verify raw-prediction recalculation, then retain the existing numeric evidence."""
    directory = root / "results/minor_revision_final_20261029"
    absolute = pd.read_csv(directory / "absolute_summary.csv")
    contrasts = pd.read_csv(directory / "contrasts_summary.csv")
    maximum = 0.0
    for index, row in summary.iterrows():
        if row.quantity not in ("own", "d8", "d8_minus_own"):
            continue
        series = f"attr:{row.feature_set}:{row.budget}"
        identifiers = variants(row.predictor)
        table = contrasts if row.quantity == "d8_minus_own" else absolute
        identity = (
            table.contrast.eq(f"{identifiers['d8']} - {identifiers['own']}")
            if row.quantity == "d8_minus_own"
            else table.variant.eq(identifiers[row.quantity])
        )
        match = table.loc[
            table.city.eq(row.city)
            & table.series.eq(series)
            & table.metric.eq("sampled_ap")
            & identity
        ]
        if len(match) != 1:
            raise ValueError("existing evidence must have exactly one matching row")
        original = match.iloc[0]
        for field in SUMMARY_FIELDS:
            error = abs(float(row[field]) - float(original[field]))
            maximum = max(maximum, error)
            if error > 5e-12:
                raise ValueError(f"existing evidence changed: {series}, {row.quantity}, {field}")
            summary.loc[index, field] = original[field]
    return maximum


def table_rows(summary: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for key, group in summary.groupby(KEYS, sort=True):
        row = dict(zip(KEYS, key, strict=True))
        lookup = group.set_index("quantity")
        for name in ("own", "adjacency", "d8"):
            row[f"{name}_ap_percent"] = 100 * lookup.loc[name, "mean"]
        for name in ("d8_minus_own", "d8_minus_adjacency"):
            for source, suffix in (
                ("mean", "pp"),
                ("range_low", "low_pp"),
                ("range_high", "high_pp"),
            ):
                row[f"{name}_{suffix}"] = 100 * lookup.loc[name, source]
            row[f"{name}_positive_folds"] = int(lookup.loc[name, "positive_folds"])
        rows.append(row)
    if len(rows) != 24:
        raise ValueError("Table 6 requires 24 complete conditions")
    return pd.DataFrame(rows)


def run(root: Path, output: Path) -> dict:
    planned, receipts = inventory(root)
    print(json.dumps({"status": "inventory_verified", "paired_units": len(planned)}), flush=True)
    rows = []
    for index, unit in enumerate(planned):
        frames = {
            role: pd.read_parquet(
                path,
                columns=[
                    "seed",
                    "bank_id",
                    "grid_id",
                    "sample_role",
                    "score",
                ],
            )
            for role, path in unit["paths"].items()
        }
        rows.append(
            {k: v for k, v in unit.items() if k != "paths"} | pair_metrics(frames, unit["seed"])
        )
        if (index + 1) % 90 == 0:
            print(json.dumps({"paired_units_evaluated": index + 1}), flush=True)
    unit_frame = pd.DataFrame(rows)
    folds, summary = summarize_units(unit_frame)
    maximum = preserve_existing(root, summary)
    table = table_rows(summary)
    output.mkdir(parents=True, exist_ok=True)
    outputs = {
        "unit_metrics.csv": unit_frame,
        "fold_values.csv": folds,
        "summary.csv": summary,
        "table6.csv": table,
    }
    for name, frame in outputs.items():
        frame.to_csv(output / name, index=False)
    evidence = root / "results/minor_revision_final_20261029"
    for name in ("absolute_summary.csv", "contrasts_summary.csv"):
        receipts[str(evidence / name)] = sha256_file(evidence / name)
    report = {
        "status": "complete",
        "run": RUN_NAME,
        "conditions": 24,
        "new_selections": 260,
        "new_inner_candidates": 520,
        "new_outer_fits": 780,
        "paired_units": len(planned),
        "existing_max_absolute_difference": maximum,
        "bank_membership_pairing": "exact grid_id/sample_role equality in all three banks",
        "aggregation": "AP per fit/bank, bank mean, within-fold mean, equal five-fold mean",
        "interval": "descriptive paired fold resampling; 10000 draws; seed 20261011",
        "source_sha256": sha256_file(Path(__file__)),
        "input_sha256": receipts,
        "output_sha256": {name: sha256_file(output / name) for name in outputs},
    }
    (output / "verification.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in report.items() if k != "input_sha256"}), flush=True)
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument(
        "--output", type=Path, default=ROOT / "results/adjacency_attribute_completion_20261124"
    )
    arguments = parser.parse_args()
    run(arguments.root, arguments.output)
