"""Complete independently selected G1 attribute controls on the frozen design."""

from __future__ import annotations

import argparse
import importlib.util
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
CONFIG = "configs/adjacency_attribute_completion_v1.yaml"
SPEC = importlib.util.spec_from_file_location(
    "historical_attribute_runner", ROOT / "scripts/run_minor_revision_controls.py"
)
historical = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(historical)

from floodgnn_ceus import e1
from floodgnn_ceus import reviewer_revision as revision
from floodgnn_ceus.experiments import E1OuterUnit
from floodgnn_ceus.io import canonical_json_bytes, sha256_bytes, sha256_file
from floodgnn_ceus.remote import validate_environment_probe
from floodgnn_ceus.training import outer_refit_epochs


def configuration() -> dict:
    return yaml.safe_load((ROOT / CONFIG).read_text("utf-8"))


def run_path(config: dict) -> Path:
    return ROOT / "artifacts/remote_runs" / config["run_id"]


def blocks(config: dict, city: str) -> list[dict]:
    if city not in config["cities"]:
        raise ValueError("city outside configured experiment")
    return [
        {
            "series": "attributes",
            "city": city,
            "outer_fold": fold,
            "budget": item["budget"],
            "trajectory": draw,
            "feature_set": feature,
            "variants": config["variants"],
        }
        for item in config["conditions"]
        for feature in item["features"]
        for fold in config["outer_folds"]
        for draw in (config["trajectories"] if item["budget"] == "100" else ["NA"])
    ]


def plan(config: dict) -> dict:
    work = [b for city in config["cities"] for b in blocks(config, city)]
    selections = len(work) * len(config["variants"])
    candidates = selections * len(config["candidates"])
    return {
        "run_id": config["run_id"],
        "blocks": len(work),
        "selections": selections,
        "inner_candidate_tasks": candidates,
        "inner_fits": candidates * len(config["inner_folds"]),
        "outer_fits": selections * len(config["outer_seeds"]),
    }


def immutable_json(path: Path, value: dict) -> None:
    if path.exists():
        if json.loads(path.read_text("utf-8")) != value:
            raise ValueError(f"refusing to replace frozen artifact: {path}")
        return
    e1._write_json(path, value)


def identity(config: dict) -> dict:
    base = ROOT / "artifacts/remote_runs" / config["base_run"] / "local_environment_lock.json"
    previous = json.loads(base.read_text("utf-8"))
    for group in ("source_files", "input_files"):
        for name, expected in previous[group].items():
            if sha256_file(ROOT / name) != expected:
                raise ValueError(f"historical {group} changed: {name}")
    sources = [ROOT / CONFIG, Path(__file__).resolve()]
    sources += sorted((ROOT / "src/floodgnn_ceus").glob("*.py"))
    return {
        "source_files": {p.relative_to(ROOT).as_posix(): sha256_file(p) for p in sources},
        "historical_lock_sha256": sha256_file(base),
        "protocol_lock_sha256": sha256_file(ROOT / "artifacts/protocol_lock.json"),
        "returned_environment_lock_sha256": sha256_file(ROOT / "artifacts/environment_lock.json"),
        "environment": historical.environment(),
    }


def freeze(config: dict) -> None:
    inherited = json.loads((ROOT / "artifacts/environment_lock.json").read_text("utf-8"))
    validate_environment_probe(inherited["environment"])
    if inherited["protocol_lock_sha256"] != sha256_file(ROOT / "artifacts/protocol_lock.json"):
        raise ValueError("returned AutoDL lock does not match protocol")
    binding = identity(config)
    revision_path = run_path(config) / "probe_environment_lock.json"
    immutable_json(revision_path, probe_environment())
    binding["revision_lock"] = revision_path.relative_to(ROOT).as_posix()
    binding["revision_lock_sha256"] = sha256_file(ROOT / binding["revision_lock"])
    immutable_json(run_path(config) / "local_environment_lock.json", binding)


def probe_environment() -> dict:
    """Bind the current allowlist independently of historical run namespaces."""
    files = revision._input_identity(ROOT)
    return {
        "schema_version": 1,
        "execution_authority": "user-requested-local-CUDA-adjacency-completion",
        "source_sha256": revision.prepare_plan(ROOT)["source_sha256"],
        "files": files,
        "input_sha256": sha256_bytes(canonical_json_bytes(files)),
        "protocol_lock_sha256": sha256_file(ROOT / "artifacts/protocol_lock.json"),
        "environment": revision._environment(),
    }


def require_probe_environment(config: dict) -> dict:
    path = run_path(config) / "probe_environment_lock.json"
    lock = json.loads(path.read_text("utf-8"))
    if lock != probe_environment():
        raise ValueError("completion probe environment changed")
    return lock


def require_lock(config: dict, *, probe: bool = True) -> None:
    path = run_path(config) / "local_environment_lock.json"
    lock = json.loads(path.read_text("utf-8"))
    for key, value in identity(config).items():
        if lock[key] != value:
            raise ValueError(f"frozen identity changed: {key}")
    if sha256_file(ROOT / lock["revision_lock"]) != lock["revision_lock_sha256"]:
        raise ValueError("local revision lock changed")
    require_probe_environment(config)
    if probe:
        receipt = json.loads((run_path(config) / "resource_probe.json").read_text("utf-8"))
        revision_lock = json.loads((ROOT / lock["revision_lock"]).read_text("utf-8"))
        validate_probe(receipt, sha256_file(path), lock["revision_lock_sha256"], revision_lock)


def validate_probe(
    receipt: dict, completion_hash: str, revision_hash: str, revision_lock: dict
) -> None:
    expected = {
        "status": "success",
        "epochs": 1,
        "cell": revision.PROBE_CELL,
        "performance_blind": True,
        "predictions_written": False,
        "metrics_computed": False,
        "completion_lock_sha256": completion_hash,
        "lock_sha256": revision_hash,
        "source_sha256": revision_lock["source_sha256"],
        "input_sha256": revision_lock["input_sha256"],
    }
    for key, value in expected.items():
        if receipt.get(key) != value or type(receipt.get(key)) is not type(value):
            raise ValueError(f"resource probe differs: {key}")


def probe(config: dict) -> dict:
    """Run the unchanged fixed one-epoch probe, writing only the new namespace."""
    require_lock(config, probe=False)
    destination = run_path(config) / "resource_probe.json"
    if destination.exists():
        require_lock(config)
        return json.loads(destination.read_text("utf-8"))
    revision_plan = revision.prepare_plan(ROOT)
    lock = require_probe_environment(config)
    import torch

    torch.set_num_threads(config["cpu_threads"])
    grid = yaml.safe_load((ROOT / "configs/model_grid.yaml").read_text("utf-8"))
    unit = E1OuterUnit("zhengzhou", 0, "20", "1")
    variant = {"id": "resource-probe", "model": "GraphSAGE-G2", "graph": "G2"}
    task = revision._task(grid, unit, variant, "SMALL", "HPO-1")
    fold = e1._inner_fold_data(e1._read_city(ROOT, unit.city), task, 0)
    train_ids = fold["train_node_ids"]
    sample_ids = fold["positive_ids"] + fold["u_ids"]
    raw = fold["raw"].loc[train_ids]
    x = revision.fit_preprocessor(raw, sample_ids, scale=True).transform(raw).to_numpy(dtype=float)
    positions = {value: i for i, value in enumerate(train_ids)}
    positive_count, u_count = len(fold["positive_ids"]), len(fold["u_ids"])
    edges = e1._partition_edge_index(fold, "G2", "train", train_ids)
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    started = time.perf_counter()
    result = revision.train_neural(
        "GraphSAGE-G2",
        grid["models"]["GraphSAGE-G2"]["SMALL"],
        x,
        edges,
        np.array([positions[value] for value in sample_ids], dtype=np.int64),
        np.r_[np.ones(positive_count), np.zeros(u_count)],
        revision.balanced_sample_weights(positive_count, u_count),
        None,
        seed=revision.seed_from_name("FloodGNN-CEUS/resource-probe"),
        max_epochs=1,
        patience=1,
        fixed_epochs=1,
    )
    torch.cuda.synchronize()
    receipt = {
        "status": "success",
        "cell": revision.PROBE_CELL,
        "epochs": result.best_epoch,
        "source_sha256": revision_plan["source_sha256"],
        "input_sha256": lock["input_sha256"],
        "lock_sha256": sha256_file(run_path(config) / "probe_environment_lock.json"),
        "completion_lock_sha256": sha256_file(run_path(config) / "local_environment_lock.json"),
        "performance_blind": True,
        "predictions_written": False,
        "metrics_computed": False,
        "nodes": len(train_ids),
        "edges": int(edges.shape[1]),
        "feature_dim": x.shape[1],
        "peak_vram_bytes": int(torch.cuda.max_memory_allocated()),
        "checkpoint_bytes": result.checkpoint_bytes,
        "wall_seconds": time.perf_counter() - started,
    }
    del result
    validate_probe(receipt, receipt["completion_lock_sha256"], receipt["lock_sha256"], lock)
    immutable_json(destination, receipt)
    return receipt


def succeeded(path: Path, payload: str, hash_key: str) -> bool:
    if not path.exists():
        return False
    status = json.loads(path.read_text("utf-8"))
    if status["status"] != "success":
        return False
    if sha256_file(path.with_name(payload)) != status[hash_key]:
        raise ValueError(f"successful task payload changed: {path}")
    return True


def selected_block(config: dict, context: dict, block: dict, members: list[str]) -> None:
    """Historical inner-only selection, followed by paired outer refits."""
    destination = run_path(config)
    unit = E1OuterUnit(block["city"], block["outer_fold"], block["budget"], block["trajectory"])

    def task_for(grid: dict, variant: dict, candidate: str, seed: str):
        return historical.make_task(
            grid, unit, variant, candidate, seed, block["feature_set"], config["run_id"]
        )

    prepared = None
    choices = {}
    for variant in config["variants"]:
        grid = historical.variant_grid(context["grid"], variant)
        tasks = []
        for candidate in config["candidates"]:
            task = task_for(grid, variant, candidate, "HPO-1")
            tasks.append(task)
            status_path = e1._status_path(destination / "inner", task)
            if succeeded(status_path, "inner_scores.parquet", "result_sha256"):
                continue
            if prepared is None:
                prepared = [
                    historical.subset(e1._inner_fold_data(context["data"], task, i), members)
                    for i in config["inner_folds"]
                ]
            status = e1.run_inner_task(
                ROOT, destination / "inner", task, context["data"], grid, prepared_folds=prepared
            )
            if status != "success":
                raise RuntimeError(f"inner fit failed: {status_path}")
        selected = e1.select_outer_models(
            ROOT,
            destination / "inner",
            unit,
            task_keys=tasks,
            models=(variant["model"],),
            alternative_order=(variant["model"],),
        )
        choice = selected["models"][variant["model"]]
        choices[variant["id"]] = {
            **choice,
            **variant,
            "refit_epochs": outer_refit_epochs(choice["best_epochs"]),
        }
    name = (
        f"attributes-{unit.city}-f{unit.outer_fold}-b{unit.budget}-"
        f"t{unit.trajectory}-{block['feature_set']}"
    )
    immutable_json(
        destination / "selections" / f"{name}.json",
        {
            "block": {k: v for k, v in block.items() if k != "variants"},
            "variants": choices,
            "selection_source": "inner sampled AP only",
        },
    )
    fold = historical.subset(e1._outer_fold_data(context["data"], unit), members)
    for variant in config["variants"]:
        grid = historical.variant_grid(context["grid"], variant)
        choice = choices[variant["id"]]
        for seed in config["outer_seeds"]:
            task = task_for(grid, variant, choice["config"], seed)
            if succeeded(e1._status_path(destination / "outer", task), "oof.parquet", "oof_sha256"):
                continue
            if (
                e1.run_outer_fit(
                    destination / "outer", task, fold, grid, epochs=choice["refit_epochs"]
                )
                != "success"
            ):
                raise RuntimeError(f"outer fit failed: {task}")


def run(config: dict, city: str, start: int, limit: int) -> None:
    require_lock(config)
    import torch

    torch.set_num_threads(config["cpu_threads"])
    context = {
        "data": e1._read_city(ROOT, city),
        "grid": yaml.safe_load((ROOT / "configs/model_grid.yaml").read_text("utf-8")),
    }
    members = historical.feature_sets()
    work = blocks(config, city)
    for index in range(start, min(start + limit, len(work))):
        started = time.perf_counter()
        block = work[index]
        selected_block(config, context, block, members[block["feature_set"]])
        progress = {
            "city": city,
            "index": index,
            "total": len(work),
            "seconds": time.perf_counter() - started,
            "block": {k: v for k, v in block.items() if k != "variants"},
        }
        e1._write_json(run_path(config) / "progress" / f"{city}.json", progress)
        print(json.dumps(progress), flush=True)


def main() -> None:
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("plan", "freeze", "probe", "run"))
    parser.add_argument("--city", choices=("zhengzhou", "beijing"))
    parser.add_argument("--start", type=int, default=0)
    parser.add_argument("--limit", type=int, default=10000)
    args = parser.parse_args()
    if args.start < 0 or args.limit < 1:
        parser.error("start must be nonnegative and limit must be positive")
    config = configuration()
    if args.action == "plan":
        print(json.dumps(plan(config)))
    elif args.action == "freeze":
        freeze(config)
    elif args.action == "probe":
        print(json.dumps(probe(config)))
    else:
        for city in [args.city] if args.city else config["cities"]:
            run(config, city, args.start, args.limit)


if __name__ == "__main__":
    main()
