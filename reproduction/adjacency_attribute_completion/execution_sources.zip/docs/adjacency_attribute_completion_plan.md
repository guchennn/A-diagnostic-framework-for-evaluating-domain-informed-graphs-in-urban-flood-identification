# Adjacency attribute completion

Complete the 20 missing Table 6 conditions with independently selected G1 fits.
Reuse the existing F18/100 main comparison, frozen feature sets, graph partitions,
positive revelations, evaluation banks, optimizer seed namespace and training code.
Preserve all existing inputs, runs and locks. New outputs use
`artifacts/remote_runs/adjacency-attributes-v1-20261124`.

The matrix has 130 blocks, 260 selections, 520 candidate tasks (1,560 inner fits),
and 780 outer refits. Each G1 predictor selects SMALL/MEDIUM using three inner
folds, then uses the historical median-best-epoch rule for three outer seeds.
No outer score enters model selection. Full-positive blocks use trajectory NA.

Before execution, test the complete matrix, selection independence, task identity,
resume payload hashes and immutable lock behavior. Freeze only when historical
source/input hashes still match and the returned AutoDL protocol lock validates.
Run the fixed performance-blind resource probe before any experimental fitting.
The new runner reuses historical data/model helpers without modifying them.

Commands, using the existing Python 3.12 CUDA environment:

```text
python scripts/run_adjacency_attribute_completion.py plan
python scripts/run_adjacency_attribute_completion.py freeze
python scripts/run_adjacency_attribute_completion.py probe
python scripts/run_adjacency_attribute_completion.py run --city zhengzhou
python scripts/run_adjacency_attribute_completion.py run --city beijing
```

Partial runs can use --start and --limit; successful task payloads are hash-checked
before reuse. Selection JSONs and successful task artifacts retain all pairing keys.
